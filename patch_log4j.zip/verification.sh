#!/bin/sh

cat /opt/eurotech/esf/user/log4j.xml | grep nolookup